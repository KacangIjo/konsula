import React from "react";
import { Routes, Route } from "react-router-dom";

import "./assets/fonts/fonts.css";
import "react-calendar/dist/Calendar.css";
import "swiper/css";

import GlobalStyle from "./GlobalStyle";
import HomePage from "./pages/HomePage";
import UniversityPlannerPage from "./pages/UniversityPlannerPage";
import SuggestionPage from "./pages/SuggestionPage";
import ConsultantPage from "./pages/ConsultantPage";
import GoToTop from "./components/GoToTop";

function App() {
  return (
    <>
      <GlobalStyle />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/planner" element={<UniversityPlannerPage />} />
        <Route path="/suggestion" element={<SuggestionPage />} />
        <Route path="/consultant" element={<ConsultantPage />} />
      </Routes>
      <GoToTop />
    </>
  );
}

export default App;
