import styled from "styled-components";

const FormLabel = styled.label`
  font-weight: 500;
`;

export default FormLabel;
