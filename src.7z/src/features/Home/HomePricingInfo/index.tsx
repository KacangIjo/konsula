import React from "react";
import Container from "../../../components/Container";
import styled from "styled-components";

const Inner = styled(Container.Inner)`
  max-width: 1000px;
  padding: 75px 0;

  @media all and (max-width: 1200px) {
    padding: 50px 32px;
  }
`;

const StyledTable = styled.table`
  width: 100%;
  border-spacing: 0;
  border-collapse: collapse;
  border: 1px solid #000;
  
  th, td {
    border: 1px solid #000;
    padding: 15px;
    width: 25%;
  }

  th {
    background-color: var(--color-primary);
    border: 1px solid var(--color--primary);
    color: #fff;
  }

  th.right,
  td.right {
    text-align: right;
  }
`

const HomePricingInfo = () => {
    const [playing, setPlaying] = React.useState(false);
    return (
        <Inner>
            <StyledTable>
                <tr>
                    <th></th>
                    <th>2018</th>
                    <th>2023</th>
                    <th>2028</th>
                </tr>

                <tr>
                    <td>ITB</td>
                    <td className='right'>20.000.000,-</td>
                    <td className='right'>46.000.000,-</td>
                    <td className='right'>93.000.000,-</td>
                </tr>

                <tr>
                    <td>Kuliah di Australia</td>
                    <td className='right'>417.105.000,-</td>
                    <td className='right'>483.539.000,-</td>
                    <td className='right'>560.554.000,-</td>
                </tr>
            </StyledTable>
        </Inner>
    );
};

export default HomePricingInfo;
