import React from "react";
import styled from "styled-components";

const Wrapper = styled.div`
  flex: 0 0 calc(33.3333% - 10px);
  max-width: 33.3333%;
  box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;
  border-bottom-left-radius: 10px;
  border-bottom-right-radius: 10px;

  @media all and (max-width: 767px) {
    flex: 0 0 100%;
    max-width: 100%;
  }
`;

const ImageWrapper = styled.div`
  width: 100%;
  padding-top: 75%;
  position: relative;
  overflow: hidden;
`;

const Image = styled.img`
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  height: 100%;
  object-fit: cover;
`;

const ContentWrapper = styled.div`
  padding: 30px 0;

  border: 1px solid rgba(0, 0, 0, 0.125);
  border-top: none;

  border-bottom-left-radius: 10px;
  border-bottom-right-radius: 10px;
`;

const Content = styled.p`
  margin: 0 0 10px;
  font-weight: 500;
  font-size: 1.25rem;
  text-align: center;

  @media all and (max-width: 575px) {
    font-size: 1rem;
  }
`;

type UniversitySuggestionItemProps = {
  imgUrl?: string;
  rank?: string;
  tuition?: string;
  admin?: string;
  living?: string;
};

const UniversitySuggestionItem = ({
  imgUrl,
  rank,
  tuition,
  admin,
  living,
}: UniversitySuggestionItemProps) => {
  return (
    <Wrapper>
      <ImageWrapper>
        <Image src={imgUrl} />
      </ImageWrapper>
      <ContentWrapper>
        <Content>World Rank: #{rank}</Content>
        <Content>Tuition Fee: {tuition}</Content>
        <Content>Admin Fee: {admin}</Content>
        <Content>Living Cost: {living}</Content>
      </ContentWrapper>
    </Wrapper>
  );
};

export default UniversitySuggestionItem;
