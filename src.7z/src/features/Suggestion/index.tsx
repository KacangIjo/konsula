import React, { useState } from "react";
import Container from "../../components/Container";
import styled from "styled-components";
import UniversitySuggestion from "./UniversitySuggestion";
import Button from "../../components/Button";
import { useNavigate } from "react-router-dom";

const Inner = styled(Container.Inner)`
  padding: 0 32px;
  max-width: 1000px;
`;

const Text = styled.p`
  margin: 0 0 10px;
  font-size: 1.25rem;
  font-weight: 500;
`;

const Suggestion = () => {
  const navigate = useNavigate();
  const [dummyLoading, setDummyLoading] = useState(false);

  const onClick = () => {
    setDummyLoading(true);
    setTimeout(() => {
      navigate("/consultant");
    }, 2000);
  };

  return (
    <Container style={{ padding: "50px 0 50px" }}>
      <Inner>
        <div>
          <Text>Berdasarkan profil Anda, kami menyarankan:</Text>
          <UniversitySuggestion />
        </div>

        <div style={{ padding: "50px 0" }}>
          <Text>
            Namun dengan perencanaan keuangan yang tepat,
            <br />
            Anda bisa menabung untuk:
          </Text>
          <UniversitySuggestion suggested={true} />
        </div>

        <Container.Flex style={{ padding: "20px 0" }} justifyContent="center">
          <Button
            onClick={onClick}
            type="button"
            size="lg"
            loading={dummyLoading}
          >
            Konsultasi Sekarang
          </Button>
        </Container.Flex>
      </Inner>
    </Container>
  );
};

export default Suggestion;
