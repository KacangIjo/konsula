import { CSSProperties } from "react";

export type CommonProps = {
  className?: string;
  style?: CSSProperties;
};
