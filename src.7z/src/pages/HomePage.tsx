import React from "react";
import HeroSection from "../components/Hero";
import Layout from "../features/Layout";
import HomeGrid from "../features/Home/HomeGrid";
import HomeVideo from "../features/Home/HomeVideo";
import HomeAction from "../features/Home/HomeAction";
import Testimonies from "../components/Testimonies";
import HomePricingInfo from "../features/Home/HomePricingInfo";

const HomePage = () => {
  return (
    <>
      <Layout>
        <HeroSection />
        <HomeGrid />
        <HomePricingInfo />
        <HomeVideo />
        <HomeAction />
        <Testimonies />
      </Layout>
    </>
  );
};

export default HomePage;
