import React from "react";
import Layout from "../features/Layout";
import UniversityPlannerTextSection from "../features/UniversityPlanner/TitleSection";
import UniversityPlannerForm from "../features/UniversityPlanner/UniversityPlannerForm";

const UniversityPlannerPage = () => {
  return (
    <>
      <Layout>
        <UniversityPlannerTextSection />
        <UniversityPlannerForm />
      </Layout>
    </>
  );
};

export default UniversityPlannerPage;
